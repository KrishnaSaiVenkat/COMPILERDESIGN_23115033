#include <iostream>

extern int yyparse();

int main() {
    std::cout << "Enter expression:\n";
    std::cout << "Examples:\n";
    std::cout << "  SI A = 1000, 2, 5;\n";
    std::cout << "  TRAPEZIUM B = 10, 6, 5;\n";
    std::cout << "  C = (1000 * 2 * 5) / 100;\n\n";
    yyparse();
    return 0;
}
